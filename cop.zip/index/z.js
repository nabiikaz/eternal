/*$(".btn btn-default search").click(function(){
	alert("this is a test");
});

$("#search_btn").click(function(){
	alert("hahahha");
});

$("document").ready(function(){
	alert("the page just loaded");
});*/


//$("#search_btn").click(search_btn_click);

//document.getElementById('search_btn').onclick=search_btn_click;

/*$(document).ready(function(){
	$('name="search_btn"').click(search_btn_click);
});*/

function search_btn_click()
{
	alert("hahahha");
	console.log("button click");
}